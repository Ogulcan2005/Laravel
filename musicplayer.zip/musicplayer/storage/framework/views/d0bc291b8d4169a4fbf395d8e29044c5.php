<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php echo $__env->yieldPushContent("styles"); ?>
</head>
<body>


<nav>
    <ul>
        <li><a href="/hello">Welkom</a></li>
        <li><a href="#">Over mij</a></li>
        <li><a href="/songs">Songs</a></li>
    </ul>
</nav>


<h1>Hallo from masterpage</h1>
<?php echo $__env->yieldContent("content"); ?>

<?php $__env->startPush("styles"); ?>
    <style>
        body{background-image: url("/images/laravel-featured.jpg");
        }
        p{
            color: red;
        }

    </style>
<?php $__env->stopPush(); ?>





<?php echo $__env->yieldPushContent("js"); ?>
</body>
</html><?php /**PATH /var/www/musicplayer/resources/views/layouts/master.blade.php ENDPATH**/ ?>
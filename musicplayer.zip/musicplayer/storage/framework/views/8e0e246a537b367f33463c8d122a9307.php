

<?php $__env->startSection("content"); ?>
<h1>Dit is de content van mij bebroetingspagina</h1>
<p>ppppppppppjiknhbijb</p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("styles"); ?>
    <style>
        body{background-image: url("/images/laravel-featured.jpg");
        }
        p{
            color: red;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/musicplayer/resources/views/hello.blade.php ENDPATH**/ ?>
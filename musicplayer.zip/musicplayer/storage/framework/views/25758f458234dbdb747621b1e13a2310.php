

<?php $__env->startSection("content"); ?>
    <h1>Hier is 1 lijst met alle liedjes</h1>
    <ul>
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($song->name); ?> - <?php echo e($song->genre->name); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/musicplayer/resources/views/songs/index.blade.php ENDPATH**/ ?>
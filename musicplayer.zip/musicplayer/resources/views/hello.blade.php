@extends("layouts.master")

@section("content")
<h1>Dit is de content van mij bebroetingspagina</h1>
<p>ppppppppppjiknhbijb</p>
@endsection

@push("styles")
    <style>
        body{background-image: url("/images/laravel-featured.jpg");
        }
        p{
            color: red;
        }

    </style>
@endpush
